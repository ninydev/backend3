<?php
namespace App\Middleware;

class Stop {

	function __construct (){
		// die ("  Stop ");
	}
}