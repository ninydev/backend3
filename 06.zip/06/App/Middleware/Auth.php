<?php
namespace App\Middleware;

class Auth {
		
}