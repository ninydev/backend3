<?php
namespace App\Layout;

/**
 * 
 */
class MainNavigationController 
{
	public static function getContent () {return "";}
}