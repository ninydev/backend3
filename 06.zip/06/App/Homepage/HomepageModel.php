<?php
namespace App\Homepage;


/**
 * 
 */
class CFModel
{
	
}