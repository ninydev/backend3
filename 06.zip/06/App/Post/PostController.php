<?php
namespace App\Post;

/**
 * 
 */
class PostController 
{
	
	function __construct(){
		echo "Post Controller";
		
	}
}