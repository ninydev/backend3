<?php
namespace App\Post;

/**
 * 
 */
class PostModel
{
	
	function __construct(){
		echo "Post Model";
		
	}
}