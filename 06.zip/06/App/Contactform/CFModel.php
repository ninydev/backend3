<?php
namespace App\Contactform;
use Kernel\Lib\Mailer;
use Kernel\Request;

/**
 * 
 */
class CFModel
{
	
	public function send (){
		$m = new Mailer();

	}


}