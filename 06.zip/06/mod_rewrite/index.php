<pre>
<?php

phpinfo();

var_dump ($GLOBALS);