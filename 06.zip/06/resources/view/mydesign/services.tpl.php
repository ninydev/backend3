<div id="containerServices" class="container">
	<h3 class="text-center">Services</h3>
	<hr>
	<p class="text-center">We offer ipsum dolor sit amet, consetetur sadipscing elitr amet</p>
	<div class="row">
		<div class="col-lg-4 text-center">
			<div class="ico"><i class="fas fa-font"></i></div>
			<h4>Clean Typography</h4>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minim</p>
		</div>
		<div class="col-lg-4 text-center">
			<div class="ico"><i class="fas fa-code"></i></div>
			<h4>Rock Solid Code</h4>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minim</p>
			
		</div>
		<div class="col-lg-4 text-center">
			<div class="ico"><i class="far fa-life-ring"></i></div>
			<h4>Expert Support</h4>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minim</p>			
		</div>		
	</div>
</div>