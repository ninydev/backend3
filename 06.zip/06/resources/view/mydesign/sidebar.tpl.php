
<?php

echo $data;
?>