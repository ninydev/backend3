<article class="siteArticle">
	<header><h1><?=(isset($data['title'])?$data['title']:'')?></h1></header>
	<div>
<hr>
<?=(isset($data['sitemap'])?$data['sitemap']:' А нету карты сайта ')?>
<hr>

	</div>
</article>