
<?php
echo \Kernel\Router::BuildItem($data, 0);
?>