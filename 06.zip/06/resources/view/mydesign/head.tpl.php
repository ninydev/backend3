  	<head>
		<meta name="description" content="Описание страницы"/>
		<meta name="keywords" content="Ключевые слова страницы"/>
		<meta name="autor" content="Oleksandr Nykytin"/>
		<meta property="og:locale" content="ru_RU"/>
		<meta charset="utf-8" />
		<meta property="og:type" content="article"/>

		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">


		<link rel="stylesheet" href="/public/css/mystyle.css">

		<title><?=(isset($data['title'])?$data['title']:' Welocme title')?></title>
	</head>