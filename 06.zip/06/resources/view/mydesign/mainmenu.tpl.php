<?php
//var_dump($data);



echo \Kernel\Router::BuildItem($data, 0);


?>


<?php
/*

		<nav id="menuMain" class="col-lg-8">
			<ul>
				<li><a href="<?=$_SERVER['PHP_SELF']?>">Home</a></li>
				<li><a href="#Services">Services</a></li>
				<li><a href="<?=$_SERVER['PHP_SELF']?>?controller=page&action=index&page_id=1">About</a></li>
				<li><a href="#Works">Works</a></li>
				<li><a href="#Blog">Blog</a></li>
				<li><a href="#Clients">Clients</a></li>
				<li><a href="<?=$_SERVER['PHP_SELF']?>?controller=contactform">Contact</a></li>
			</ul>
		</nav>

*/