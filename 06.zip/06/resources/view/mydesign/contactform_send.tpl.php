Contcact form
<article class="siteArticle">
	<header><h1><?=(isset($data['pageTitle'])?$data['pageTitle']:'')?></h1></header>
	<div>

		Отправлено 

	</div>
	<footer><span> <?=(isset($data['comment'])?$data['comment']:'')?></span></footer>
</article>