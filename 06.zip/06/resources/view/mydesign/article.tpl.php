<article class="siteArticle">
	<header><h1><?=(isset($data['title'])?$data['title']:'')?></h1></header>
	<img src="https://nikolaev.itstep.org/wp-content/uploads/2018/10/done-2_site.jpg">
	<div>
		<details>Content</details>
	</div>
	<footer><span> <?=(isset($data['comment'])?$data['comment']:'')?></span></footer>
</article>