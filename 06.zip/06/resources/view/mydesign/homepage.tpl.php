HomePage
<article class="siteArticle">
	<header><h1><?=(isset($data['pageTitle'])?$data['pageTitle']:'')?></h1></header>
	<div>
	</div>
</article>