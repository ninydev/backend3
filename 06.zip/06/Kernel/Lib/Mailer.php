<?php
namespace Kernel\Lib;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

use App\Config;

/**
 * 
 */
class Mailer extends PHPMailer
{
	
	function __construct() {

	}
}