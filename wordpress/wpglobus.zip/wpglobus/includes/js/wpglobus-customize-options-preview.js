/**
 * WPGlobus Customize Preview
 * Interface JS functions
 *
 * @since 1.4.6
 *
 * @package WPGlobus
 * @subpackage Customize Preview
 */
/*jslint browser: true*/
/*global jQuery, console  */
jQuery(document).ready(function ($) {	
	/*	
	wp.customize( 'wpglobus_customize_language_selector_mode', function( value ) {
		value.bind( function( newval ) {
			//$( '.nav-menu' ).html( newval );
		} );
	} ); */
	
});	
