<?php
/**
 * 
 */
class Loco_test_TransientObject extends Loco_data_Transient {
    
    
    public function getKey(){
        return 'test_object';
    }
    
    
}