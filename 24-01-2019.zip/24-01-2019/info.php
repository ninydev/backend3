<?php
phpinfo ();